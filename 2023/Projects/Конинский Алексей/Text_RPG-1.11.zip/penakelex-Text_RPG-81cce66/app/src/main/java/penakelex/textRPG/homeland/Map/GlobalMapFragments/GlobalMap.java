package penakelex.textRPG.homeland.Map.GlobalMapFragments;

import androidx.fragment.app.Fragment;

public interface GlobalMap {
    void setClickable();
    void startLocation();
    void firstButton();
    void secondButton();
    void thirdButton();
    void fourthButton();
    void fifthButton();
    void sixthButton();
    void seventhButton();
    void eighthButton();
    void ninthButton();
    void settingNothing(int destination);
    void settingNothingToLocation(int location);
}
