package penakelex.textRPG.homeland.Adapters.Reputations;

public class ReputationInformation {
    private String name;

    public ReputationInformation(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
