package mivlix.alpha.greedcity;

public class QuestionManager {
    //TODO: Вопроситель
}
