package mivlix.alpha.greedcity;

public class TextManager {
    //TODO: Текстователь
}
