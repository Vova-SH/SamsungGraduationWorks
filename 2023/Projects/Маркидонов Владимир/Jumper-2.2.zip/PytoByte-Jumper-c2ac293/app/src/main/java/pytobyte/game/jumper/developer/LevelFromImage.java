package pytobyte.game.jumper.developer;

public class LevelFromImage {}
