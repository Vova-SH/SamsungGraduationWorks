package pytobyte.game.jumper.UI.items.shop;

public class Skin {
    int skinID;

    public int getSkinID() {
        return skinID;
    }

    public void setSkinID(int skinID) {
        this.skinID = skinID;
    }

    public Skin(int skinID) {
        this.skinID = skinID;
    }
}
