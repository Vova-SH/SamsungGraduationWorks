package com.example.esperanto;

public class word {
    private String ES;
    private String RU;

    public word(String ES, String RU) {
        this.ES = ES;
        this.RU = RU;
    }
    public String getES() {
        return ES;
    }
    public void setES(String ES) {
        this.ES = ES;
    }
    public String getRU() {
        return RU;
    }
    public void setRU(String RU) {
        this.RU = RU;
    }




}
