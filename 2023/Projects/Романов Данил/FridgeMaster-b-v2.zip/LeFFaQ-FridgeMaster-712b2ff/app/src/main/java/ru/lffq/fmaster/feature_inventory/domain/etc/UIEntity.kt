package ru.lffq.fmaster.feature_inventory.domain.etc

interface UIEntity