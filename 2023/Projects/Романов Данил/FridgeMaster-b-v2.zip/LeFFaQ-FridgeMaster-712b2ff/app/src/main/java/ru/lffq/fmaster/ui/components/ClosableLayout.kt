package ru.lffq.fmaster.ui.components

interface ClosableLayout {
    fun close()
}