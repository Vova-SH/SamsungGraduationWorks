package ru.lffq.fmaster.feature_catalog

import androidx.compose.runtime.Composable


@Composable
fun Catalog() {

}