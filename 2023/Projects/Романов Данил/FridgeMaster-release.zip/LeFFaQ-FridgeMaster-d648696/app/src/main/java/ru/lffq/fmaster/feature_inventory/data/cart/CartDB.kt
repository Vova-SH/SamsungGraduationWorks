package ru.lffq.fmaster.feature_inventory.data.cart

class CartDB {
}