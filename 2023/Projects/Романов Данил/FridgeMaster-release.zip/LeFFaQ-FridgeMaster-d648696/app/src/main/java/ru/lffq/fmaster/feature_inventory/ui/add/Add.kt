package ru.lffq.fmaster.feature_inventory.ui.add

import androidx.compose.runtime.Composable


@Composable
fun AddLayout() {

}