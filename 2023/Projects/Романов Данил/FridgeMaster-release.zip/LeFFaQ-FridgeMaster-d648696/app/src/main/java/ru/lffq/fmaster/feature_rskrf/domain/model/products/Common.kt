package ru.lffq.fmaster.feature_rskrf.domain.model

data class CriteriaRating(
    val title: String,
    val value: Double
)
