package com.example.notesapp.adapter;

import com.example.notesapp.Note;

public interface OnNoteLongClickedListener {
    boolean onNoteLongClicked(Note note);
}
