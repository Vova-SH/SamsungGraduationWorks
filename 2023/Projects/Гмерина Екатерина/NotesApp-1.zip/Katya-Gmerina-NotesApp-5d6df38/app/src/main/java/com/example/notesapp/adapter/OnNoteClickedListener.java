package com.example.notesapp.adapter;

import com.example.notesapp.Note;

public interface OnNoteClickedListener {
    void onNoteClicked(Note note);
}
