package com.example.egeudareniafinal.Stats;

public class Note {
    private final String title, account;

    public Note(String title, String account) {
        this.title = title;
        this.account = account;
    }

    public String getTitle() {
        return title;
    }

    public String getaccount() {
        return account;
    }
}
