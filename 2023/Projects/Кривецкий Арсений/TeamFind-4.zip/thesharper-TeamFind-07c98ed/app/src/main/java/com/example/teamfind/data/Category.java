package com.example.teamfind.data;

import android.graphics.drawable.Drawable;

public class Category {
    public String name;
    public int drawable_id;

    public Category(String name, int drawable_id){
        this.name = name;
        this.drawable_id = drawable_id;
    }
}
