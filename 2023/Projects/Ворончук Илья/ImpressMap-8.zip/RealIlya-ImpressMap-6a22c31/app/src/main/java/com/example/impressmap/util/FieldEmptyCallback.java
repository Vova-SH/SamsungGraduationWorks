package com.example.impressmap.util;

public interface FieldEmptyCallback
{
    void onEmpty();
}
