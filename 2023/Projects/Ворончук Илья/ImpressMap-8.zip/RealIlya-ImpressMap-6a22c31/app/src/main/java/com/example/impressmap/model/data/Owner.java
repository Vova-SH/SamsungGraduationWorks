package com.example.impressmap.model.data;

import android.os.Parcelable;

import java.io.Serializable;

public interface Owner extends Parcelable
{
    String getId();
}
