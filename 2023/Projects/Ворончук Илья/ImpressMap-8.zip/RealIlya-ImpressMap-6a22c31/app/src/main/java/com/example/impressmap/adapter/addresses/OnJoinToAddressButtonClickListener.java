package com.example.impressmap.adapter.addresses;

import com.example.impressmap.model.data.Address;

public interface OnJoinToAddressButtonClickListener
{
    void onJoinToAddressClick(Address address);
}
