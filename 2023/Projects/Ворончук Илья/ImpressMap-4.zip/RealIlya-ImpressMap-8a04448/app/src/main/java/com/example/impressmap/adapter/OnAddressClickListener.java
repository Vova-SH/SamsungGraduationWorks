package com.example.impressmap.adapter;

import com.example.impressmap.model.data.Address;

public interface OnAddressClickListener
{
    void onAddressClick(Address address);
}
