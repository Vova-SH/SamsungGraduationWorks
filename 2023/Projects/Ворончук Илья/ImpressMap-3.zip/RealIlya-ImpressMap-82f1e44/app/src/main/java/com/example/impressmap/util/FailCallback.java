package com.example.impressmap.util;

public interface FailCallback
{
    void onFail();
}
