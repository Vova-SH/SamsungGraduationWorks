package com.example.impressmap.model.data;

public interface GObject
{
    boolean isSelected();

    void setSelected(boolean selected);
}
