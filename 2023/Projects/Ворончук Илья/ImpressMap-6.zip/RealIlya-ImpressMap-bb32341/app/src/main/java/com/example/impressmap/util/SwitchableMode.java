package com.example.impressmap.util;

public interface SwitchableMode
{
    void switchMode(int mode);
}
