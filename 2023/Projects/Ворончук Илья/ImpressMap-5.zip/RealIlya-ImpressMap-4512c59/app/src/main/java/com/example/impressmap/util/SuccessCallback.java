package com.example.impressmap.util;

public interface SuccessCallback
{
    void onSuccess();
}
