package ru.sunzar.myitschool.data;

public class MiningData {
    public static float btc_offline_count = 0.0f;
    public static float btc_offline_time = 10f;
    public static float btc_add = 0.000005f;
    public static int percentage_durability_videacard = 100;
    public static int percentage_decrease = 10;
    public static float price_buy_videocard = 0.0f;
}
