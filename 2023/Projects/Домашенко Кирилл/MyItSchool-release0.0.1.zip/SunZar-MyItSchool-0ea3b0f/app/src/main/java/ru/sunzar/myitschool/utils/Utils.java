package ru.sunzar.myitschool.utils;

public class Utils {
    public static final String BASE_URL = "https://cdn.jsdelivr.net/";
}
