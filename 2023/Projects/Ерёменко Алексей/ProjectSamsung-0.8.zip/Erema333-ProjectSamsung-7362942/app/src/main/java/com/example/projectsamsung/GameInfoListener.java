package com.example.projectsamsung;

import com.example.projectsamsung.Activitys.GameActivity;

public interface GameInfoListener{
     void callingBack(GameActivity activty);



}

