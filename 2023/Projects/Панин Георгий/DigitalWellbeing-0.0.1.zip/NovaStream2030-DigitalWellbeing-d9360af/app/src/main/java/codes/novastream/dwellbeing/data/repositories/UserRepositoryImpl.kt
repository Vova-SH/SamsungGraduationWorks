package codes.novastream.dwellbeing.data.repositories

import codes.novastream.dwellbeing.data.dao.UserDao
import codes.novastream.dwellbeing.data.entities.User
import codes.novastream.dwellbeing.domain.repositories.UserRepository
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepositoryImpl @Inject constructor(
    private val userDao: UserDao
) : UserRepository {
    override suspend fun getUser(id: Int): User? {
        return userDao.getById(id)
    }

    override suspend fun userExists(id: Int): Boolean {
        val user = userDao.getById(id)

        return user != null
    }

    override suspend fun createUser() {
        userDao.insertAll(
            User(
                id = 0,
                email = "",
                exp = 0
            )
        )
    }
}