package codes.novastream.dwellbeing.ui.rating

import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.viewModels
import codes.novastream.dwellbeing.R
import codes.novastream.dwellbeing.databinding.FragmentRatingBinding
import com.google.android.material.tabs.TabLayoutMediator
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class RatingFragment : Fragment() {
    private val viewModel: RatingViewModel by viewModels()

    private var _binding: FragmentRatingBinding? = null
    private val binding get() = _binding!!

    private val tabsAdapter: TabsAdapter = TabsAdapter()

    private val tabTitles = arrayListOf("Глобальный", "Друзья (скоро)")
    private val tabIcons = arrayListOf<Drawable>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentRatingBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.header.headerTitle.text = "Рейтинг"

        tabIcons.add(ResourcesCompat.getDrawable(resources, R.drawable.ic_public, null)!!)
        tabIcons.add(ResourcesCompat.getDrawable(resources, R.drawable.ic_hourglass_top, null)!!)

        binding.pager.adapter = tabsAdapter
        TabLayoutMediator(binding.topTabs, binding.pager) { tab, position ->
            tab.icon = tabIcons[position]
            tab.text = tabTitles[position]
        }.attach()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}