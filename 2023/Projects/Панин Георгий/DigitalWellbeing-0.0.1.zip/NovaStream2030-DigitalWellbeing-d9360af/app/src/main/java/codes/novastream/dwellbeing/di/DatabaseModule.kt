package codes.novastream.dwellbeing.di

import android.content.Context
import androidx.room.Room
import codes.novastream.dwellbeing.data.database.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
class DatabaseModule {
    @Provides
    fun provideKvDao(appDatabase: AppDatabase) = appDatabase.kvDao()

    @Provides
    fun provideUserDao(appDatabase: AppDatabase) = appDatabase.userDao()

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext appContext: Context)
        = Room.databaseBuilder(
            appContext,
            AppDatabase::class.java,
        "digital_health.db"
        ).fallbackToDestructiveMigration().build()
}