package codes.novastream.dwellbeing.domain.repositories

import codes.novastream.dwellbeing.data.entities.User

interface UserRepository {
    suspend fun getUser(id: Int): User?

    suspend fun userExists(id: Int): Boolean

    suspend fun createUser()
}