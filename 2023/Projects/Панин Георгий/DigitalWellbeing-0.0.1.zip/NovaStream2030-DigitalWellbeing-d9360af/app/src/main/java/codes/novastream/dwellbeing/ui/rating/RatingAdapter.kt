package codes.novastream.dwellbeing.ui.rating

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import codes.novastream.dwellbeing.R
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RatingAdapter @Inject constructor()
    : RecyclerView.Adapter<RatingAdapter.ViewHolder>() {

        class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_top_user, parent)
        )
    }

    override fun getItemCount(): Int = 100

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

    }
}