package codes.novastream.dwellbeing.data.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class User(
    @PrimaryKey val id: Long,
    @ColumnInfo(name = "email") val email: String?,
    @ColumnInfo(name = "exp") val exp: Int,
)
