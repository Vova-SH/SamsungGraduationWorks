package codes.novastream.dwellbeing.ui.profile

import androidx.lifecycle.ViewModel

class ProfileViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}