package codes.novastream.dwellbeing.data.dao

import androidx.room.Dao

@Dao
class ChallengeDao
