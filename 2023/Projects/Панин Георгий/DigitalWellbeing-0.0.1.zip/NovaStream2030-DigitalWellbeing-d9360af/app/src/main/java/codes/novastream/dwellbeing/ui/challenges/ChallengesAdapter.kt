package codes.novastream.dwellbeing.ui.challenges

import android.annotation.SuppressLint
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import codes.novastream.dwellbeing.data.entities.Challenge
import codes.novastream.dwellbeing.databinding.ComponentChallengeCardBinding
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChallengesAdapter @Inject constructor() :
    RecyclerView.Adapter<ChallengesAdapter.CarouselItemViewHolder>() {
    private var challenges: ArrayList<Challenge> = ArrayList()

    class CarouselItemViewHolder(private val binding: ComponentChallengeCardBinding)
        : RecyclerView.ViewHolder(binding.root) {
            fun bind(challenge: Challenge) {
                binding.apply {
                    challengeTitle.text = challenge.name
                    challengeRunTime.text = challenge.time
                    challengeCategory.text = challenge.category
                    challengeExpCount.text = challenge.exp
                    challengeButton.setOnClickListener {
                        Navigation.findNavController(this.root).navigate(
                            ChallengesFragmentDirections.actionChallengesFragmentToChallengeFragment()
                        )
                    }
                }
            }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setChallenges(challenges: ArrayList<Challenge>) {
        this.challenges = challenges
        notifyItemRangeChanged(0, challenges.size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarouselItemViewHolder {
        return CarouselItemViewHolder(
            ComponentChallengeCardBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: CarouselItemViewHolder, position: Int) {
        holder.bind(challenges[position])
    }

    override fun getItemCount() = challenges.size
}