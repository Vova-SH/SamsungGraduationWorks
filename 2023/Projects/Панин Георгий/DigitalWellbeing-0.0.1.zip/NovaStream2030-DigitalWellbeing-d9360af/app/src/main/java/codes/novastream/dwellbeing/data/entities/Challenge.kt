package codes.novastream.dwellbeing.data.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Challenge(
    @PrimaryKey val id: Long,
    @ColumnInfo(name = "name") val name: String?,
    @ColumnInfo(name = "exp") val exp: String?,
    @ColumnInfo(name = "category") val category: String?,
    @ColumnInfo(name = "time") val time: String?,
    @ColumnInfo(name = "favorite") val favorite: String?
)
