package codes.novastream.dwellbeing.ui.rating

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class TabsAdapter : RecyclerView.Adapter<TabsAdapter.ViewHolder>() {
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view)

    override fun getItemCount() = 2

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val fragment = UserListFragment()

        val view = fragment.onCreateView(LayoutInflater.from(parent.context), parent, null)
        fragment.onViewCreated(view, null)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {}
}