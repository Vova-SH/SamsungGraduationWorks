package codes.novastream.dwellbeing.ui.onboarding

data class OnboardingSlide(
    val image: String = "https://randompicturegenerator.com/img/flower-generator/g0ab91415c8fbdb777b90bf5280c9b100f1d87e7404241abce297d952c3754a74d892d61782d67e8bead840147d471bd5_640.jpg",
    val title: String = "",
    val description: String = "",
    val imageResource: Int? = null
)
