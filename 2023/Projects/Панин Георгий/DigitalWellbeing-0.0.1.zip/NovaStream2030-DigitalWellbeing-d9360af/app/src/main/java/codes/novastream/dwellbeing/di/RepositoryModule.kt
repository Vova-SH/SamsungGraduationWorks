package codes.novastream.dwellbeing.di

import codes.novastream.dwellbeing.data.repositories.ChallengesRepositoryImpl
import codes.novastream.dwellbeing.data.repositories.SettingsRepositoryImpl
import codes.novastream.dwellbeing.data.repositories.UserRepositoryImpl
import codes.novastream.dwellbeing.domain.repositories.ChallengesRepository
import codes.novastream.dwellbeing.domain.repositories.SettingsRepository
import codes.novastream.dwellbeing.domain.repositories.UserRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent

@InstallIn(ActivityComponent::class)
@Module
abstract class RepositoryModule {
    @Binds
    abstract fun providesSettingsRepository(impl: SettingsRepositoryImpl): SettingsRepository

    @Binds
    abstract fun providesUserRepository(impl: UserRepositoryImpl): UserRepository

    @Binds
    abstract fun providesChallengesRepository(impl: ChallengesRepositoryImpl): ChallengesRepository
}