package codes.novastream.dwellbeing.data.repositories

import android.content.res.AssetManager
import android.content.res.loader.AssetsProvider
import codes.novastream.dwellbeing.data.entities.Challenge
import codes.novastream.dwellbeing.domain.repositories.ChallengesRepository
import com.google.gson.Gson
import java.io.IOException
import java.io.InputStream
import java.nio.charset.Charset
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class ChallengesRepositoryImpl @Inject constructor() : ChallengesRepository {
    private var challenges: List<Challenge> = arrayListOf()

    override fun getChallengesFromFile(assetManager: AssetManager) {
        var json = ""

//        try {
//            val inputStream: InputStream = assetManager.open("data/challenges/challgenges.json")
//            val size = inputStream.available()
//            val buffer = ByteArray(size)
//
//            inputStream.read(buffer)
//            inputStream.close()
//
//            json = String(buffer, Charset.defaultCharset())
//        } catch (ex: IOException) {
//            ex.printStackTrace()
//        }
//
//        challenges = Gson().fromJson<List<Challenge>>(json, Challenge::class.java)
//
//        println(challenges.size)
    }
}