package codes.novastream.dwellbeing.ui.main

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavController
import androidx.navigation.NavOptions
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import codes.novastream.dwellbeing.R
import codes.novastream.dwellbeing.domain.repositories.SettingsRepository
import codes.novastream.dwellbeing.databinding.ActivityMainBinding
import codes.novastream.dwellbeing.domain.repositories.ChallengesRepository
import codes.novastream.dwellbeing.domain.repositories.UserRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var navController: NavController
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    @Inject
    lateinit var settingsRepository: SettingsRepository

    @Inject
    lateinit var userRepository: UserRepository

    @Inject
    lateinit var challengesRepository: ChallengesRepository

    @SuppressLint("ResourceType")
    override fun onCreate(savedInstanceState: Bundle?) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.hide()

        val navHostFragment = supportFragmentManager.findFragmentById(
            R.id.nav_host_container
        ) as NavHostFragment
        navController = navHostFragment.navController

        val bottomNavigationView = binding.bottomNav
        bottomNavigationView.setupWithNavController(navController)

        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)

        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.loginFragment,
                R.id.onboardingFragment,
                R.id.challengeFragment
                    -> bottomNavigationView.visibility = View.GONE
                else -> bottomNavigationView.visibility = View.VISIBLE
            }
        }

        challengesRepository.getChallengesFromFile(assets)

        lifecycleScope.launch {
            if (userRepository.userExists(0))
                navController.navigate(
                    R.id.challengesFragment,
                    null,
                    NavOptions.Builder()
                        .setPopUpTo(R.navigation.nav_graph, inclusive = true)
                        .build()
                )
            else
                navController.navigate(
                    R.id.onboardingFragment,
                    null,
                    NavOptions.Builder()
                        .setPopUpTo(R.navigation.nav_graph, inclusive = true)
                        .build()
                )
        }

    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }
}