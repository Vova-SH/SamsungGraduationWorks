package codes.novastream.dwellbeing.utils


// TODO: make api requests
interface Api {
}