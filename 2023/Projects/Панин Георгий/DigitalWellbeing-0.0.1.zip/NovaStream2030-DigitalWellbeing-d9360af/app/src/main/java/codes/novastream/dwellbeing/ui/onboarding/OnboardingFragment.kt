package codes.novastream.dwellbeing.ui.onboarding

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import codes.novastream.dwellbeing.R
import codes.novastream.dwellbeing.databinding.FragmentOnboardingBinding
import codes.novastream.dwellbeing.domain.repositories.UserRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class OnboardingFragment : Fragment() {
    private var _binding: FragmentOnboardingBinding? = null
    private val binding get() = _binding!!

    @Inject
    lateinit var adapter: OnboardingSlidesAdapter

    @Inject
    lateinit var userRepository: UserRepository

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentOnboardingBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val slides = arrayListOf(
            OnboardingSlide(
                title = "Добро пожаловать в «Цифровое здоровье»!",
                description = "Это приложение поможет вам снизить время, проводимое в телефоне.",
                imageResource = R.drawable.first_onboarding_screen
            ),
            OnboardingSlide(
                title = "Как?",
                description = "Приложение предлагает каждый день выполнять одно задание. " +
                        "Задания заставляют задуматься о каждой минуте, проводимой в телефоне.",
                imageResource = R.drawable.second_onboarding_slide
            ),
            OnboardingSlide(
                title = "Хотите освободить больше времени?",
                description = "Осозновая свой образ жизни, можно вывести себя к идеалу. " +
                        "Выполняйте задания и становитесь идеальной версией себя! " +
                        "Верните контроль над своей жизнью в телефоне!",
                imageResource = R.drawable.third_onboarding_slide
            )
        )

        adapter.setSlides(slides)

        val pager = binding.pager

        pager.apply {
            clipChildren = false
            clipToPadding = false
            offscreenPageLimit = 3
            (getChildAt(0) as RecyclerView).overScrollMode =
                RecyclerView.OVER_SCROLL_NEVER
            adapter = this@OnboardingFragment.adapter
        }

        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)

                if (position == adapter.itemCount - 1) {
                    binding.actionButton.text = "Конечно!"
                } else {
                    binding.actionButton.text = "Далее"
                }
            }
        })

        binding.actionButton.setOnClickListener {
            if (pager.currentItem == adapter.itemCount - 1) {
                lifecycleScope.launch {
                    userRepository.createUser()
                    findNavController().navigate(R.id.challengesFragment)
                }
            } else {
                pager.currentItem += 1
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}