package codes.novastream.dwellbeing.ui.challenges

import android.content.res.Resources
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.CompositePageTransformer
import androidx.viewpager2.widget.MarginPageTransformer
import codes.novastream.dwellbeing.R
import codes.novastream.dwellbeing.data.entities.Challenge
import codes.novastream.dwellbeing.databinding.FragmentChallengesBinding
import codes.novastream.dwellbeing.databinding.FragmentLoginBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.lang.Math.abs
import javax.inject.Inject

//private const val ARG_PARAM1 = "param1"
//private const val ARG_PARAM2 = "param2"

@AndroidEntryPoint
class ChallengesFragment : Fragment() {
    private var _binding: FragmentChallengesBinding? = null
    private val binding get() = _binding!!

    @Inject lateinit var adapter: ChallengesAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChallengesBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.header.headerTitle.text = "Задания"

        val demoData = arrayListOf(
            Challenge(1, "Оценивая скуку", "10 опыта", "Продуктивность", "10 мин", "true"),
            Challenge(2, "Оценивая скуку", "10 опыта", "Продуктивность", "10 мин", "true"),
            Challenge(3, "Оценивая скуку", "10 опыта", "Продуктивность", "10 мин", "true")
        )

        adapter.setChallenges(demoData)

        val viewPager = binding.carousel

        val compositePageTransformer = CompositePageTransformer()

        compositePageTransformer.addTransformer(MarginPageTransformer((2 * Resources.getSystem().displayMetrics.density).toInt()))
        compositePageTransformer.addTransformer { page, position ->
            val r = 1 - abs(position)
            page.scaleY = (0.80f + r * 0.20f)
        }

        viewPager.apply {
            clipChildren = false
            clipToPadding = false
            offscreenPageLimit = 3
            (getChildAt(0) as RecyclerView).overScrollMode =
                RecyclerView.OVER_SCROLL_NEVER
            setPageTransformer(compositePageTransformer)
            adapter = this@ChallengesFragment.adapter
            setCurrentItem(1, false)
        }
    }
}