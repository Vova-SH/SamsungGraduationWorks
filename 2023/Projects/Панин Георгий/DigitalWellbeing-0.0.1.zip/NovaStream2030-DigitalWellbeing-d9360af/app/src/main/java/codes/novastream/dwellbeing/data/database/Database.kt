package codes.novastream.dwellbeing.data.database

import androidx.room.AutoMigration
import androidx.room.Database
import androidx.room.RoomDatabase
import codes.novastream.dwellbeing.data.dao.KVDao
import codes.novastream.dwellbeing.data.dao.UserDao
import codes.novastream.dwellbeing.data.entities.KV
import codes.novastream.dwellbeing.data.entities.User

@Database(
    entities = [User::class, KV::class],
    version = 1,
//    autoMigrations = [
//        AutoMigration(
//            from = 1,
//            to = 2,
//        ),
//    ],
    exportSchema = true
)
abstract class AppDatabase: RoomDatabase() {
    abstract fun userDao(): UserDao

    abstract fun kvDao(): KVDao
}