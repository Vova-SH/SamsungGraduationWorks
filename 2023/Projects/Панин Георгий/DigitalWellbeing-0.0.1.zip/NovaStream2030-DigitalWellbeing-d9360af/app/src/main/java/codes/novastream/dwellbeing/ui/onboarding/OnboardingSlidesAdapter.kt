package codes.novastream.dwellbeing.ui.onboarding

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import codes.novastream.dwellbeing.data.entities.Challenge
import codes.novastream.dwellbeing.databinding.ItemOnboardingSlideBinding
import com.squareup.picasso.Picasso
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OnboardingSlidesAdapter @Inject constructor()
    : RecyclerView.Adapter<OnboardingSlidesAdapter.ViewHolder>() {
    private var slides: ArrayList<OnboardingSlide> = arrayListOf()

    class ViewHolder(private val binding: ItemOnboardingSlideBinding)
        : RecyclerView.ViewHolder(binding.root) {
        fun bind(slide: OnboardingSlide) {
            binding.apply {
                if (slide.imageResource != null)
                    image.setImageResource(slide.imageResource)
                else
                    Picasso.get().load(slide.image).into(image)
                title.text = slide.title
                description.text = slide.description
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setSlides(slides: ArrayList<OnboardingSlide>) {
        this.slides = slides
        notifyItemRangeChanged(0, slides.size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemOnboardingSlideBinding.inflate(
                LayoutInflater.from(parent.context),
                parent, false
            )
        )
    }

    override fun getItemCount(): Int = slides.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int)
        = holder.bind(slides[position])
}