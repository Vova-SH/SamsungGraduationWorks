package codes.novastream.dwellbeing.domain.repositories

interface SettingsRepository {
    suspend fun isFirstLaunch(): Boolean
}