package codes.novastream.dwellbeing.data.repositories

import codes.novastream.dwellbeing.data.dao.KVDao
import codes.novastream.dwellbeing.data.entities.KV
import codes.novastream.dwellbeing.domain.repositories.SettingsRepository
import javax.inject.Inject

class SettingsRepositoryImpl @Inject constructor(private val kvDao: KVDao) : SettingsRepository {
    private val IS_FIRST_LAUNCH_KEY = "IS_FIRST_LAUNCH"

    override suspend fun isFirstLaunch(): Boolean {
        val firstLaunchKv = kvDao.getByKey(IS_FIRST_LAUNCH_KEY)

        if (firstLaunchKv == null) {
            kvDao.insert(
                KV(0, IS_FIRST_LAUNCH_KEY, "false")
            )

            return true
        }
        if (firstLaunchKv.value == "true") {
            firstLaunchKv.value = "false"
            kvDao.update(firstLaunchKv)
        }

        return firstLaunchKv.value == "true"
    }
}