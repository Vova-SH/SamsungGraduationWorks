package codes.novastream.dwellbeing.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import codes.novastream.dwellbeing.data.entities.KV

@Dao
interface KVDao {
    @Query("SELECT * FROM kv")
    suspend fun getAll(): List<KV>

    @Insert
    suspend fun insertAll(vararg kvs: KV)

    @Insert
    suspend fun insert(kv: KV)

    @Delete
    suspend fun delete(kv: KV)

    @Update
    suspend fun update(kv: KV)

    @Query("SELECT * FROM kv WHERE `key` LIKE :key")
    suspend fun getByKey(key: String): KV?
}