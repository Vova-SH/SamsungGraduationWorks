package codes.novastream.dwellbeing.core

object Constants {
    const val TAG = "DigitalWellbeing"

    const val SIGN_IN_REQUEST = "signInRequest"
    const val SIGN_UP_REQUEST = "signUpRequest"
}