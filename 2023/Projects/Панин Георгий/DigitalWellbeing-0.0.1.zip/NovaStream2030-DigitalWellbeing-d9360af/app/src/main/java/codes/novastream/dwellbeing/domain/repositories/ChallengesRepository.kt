package codes.novastream.dwellbeing.domain.repositories

import android.content.res.AssetManager

interface ChallengesRepository {
    fun getChallengesFromFile(assetManager: AssetManager)
}
