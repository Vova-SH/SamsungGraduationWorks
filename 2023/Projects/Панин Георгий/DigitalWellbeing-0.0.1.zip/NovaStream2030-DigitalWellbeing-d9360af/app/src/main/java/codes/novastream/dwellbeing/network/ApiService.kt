package codes.novastream.dwellbeing.network

interface ApiService {
}