package ru.myitschool.lesson20221216_1;

import android.view.View;

public interface Item {
    void onClick(View view);
}
