package com.daregol.studentbase.ui.facilities;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.daregol.studentbase.AppExecutors;
import com.daregol.studentbase.DataRepository;
import com.daregol.studentbase.data.Facility;
import com.daregol.studentbase.db.AppDatabase;

import java.util.List;

public class FacilitiesViewModel extends AndroidViewModel {
    private final LiveData<List<Facility>> facilities;

    public FacilitiesViewModel(@NonNull Application application) {
        super(application);

        AppExecutors executors = AppExecutors.getInstance();
        AppDatabase database = AppDatabase.getInstance(application, executors);
        DataRepository repository = DataRepository.getInstance(database);

        facilities = repository.getFacilities();
    }

    public LiveData<List<Facility>> getFacilities() {
        return facilities;
    }
}
