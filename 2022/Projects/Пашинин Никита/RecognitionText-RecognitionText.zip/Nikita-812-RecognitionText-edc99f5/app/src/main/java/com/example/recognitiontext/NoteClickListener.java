package com.example.recognitiontext;

public interface NoteClickListener {
    void onClick(TextDb note);
}
