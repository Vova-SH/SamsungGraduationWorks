package com.example.recognitiontext.ui;

import com.example.recognitiontext.db.TextDb;

public interface NoteClickListener {
    void onClick(TextDb note);
}
