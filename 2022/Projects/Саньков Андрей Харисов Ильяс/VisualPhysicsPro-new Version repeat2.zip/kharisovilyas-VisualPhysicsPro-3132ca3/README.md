# VisualPhysicsPro
An application that helps schoolchildren in Physics lessons, teaches them about physical phenomena 
