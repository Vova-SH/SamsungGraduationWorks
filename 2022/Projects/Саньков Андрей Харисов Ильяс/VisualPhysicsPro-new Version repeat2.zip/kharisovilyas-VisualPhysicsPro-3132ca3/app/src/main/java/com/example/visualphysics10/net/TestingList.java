package com.example.visualphysics10.net;

import java.util.List;

public class TestingList {
    public List<Testings> getTask() {
        return task;
    }

    public List<Testings> task;
}
