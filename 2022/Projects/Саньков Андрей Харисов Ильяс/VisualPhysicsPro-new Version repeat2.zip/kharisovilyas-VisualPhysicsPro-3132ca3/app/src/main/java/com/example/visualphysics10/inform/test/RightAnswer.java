package com.example.visualphysics10.inform.test;

abstract class RightAnswer {

    public static boolean task1FromL1(double ans){
        boolean answer;
        answer = (ans == 50.00);
        return answer;
    }

    public static boolean task2FromL1(double ans){
        boolean answer;
        answer = (ans == 25.00);
        return answer;
    }

    public static boolean task1FromL2(double ans) {
        boolean answer;
        answer = (ans == 1.90);
        return answer;
    }
    public static boolean task2FromL2(double ans) {
        boolean answer;
        answer = (ans == 6.00);
        return answer;
    }
    public static boolean task1FromL3(double ans) {
        boolean answer;
        answer = (ans == 60.00);
        return answer;
    }
    public static boolean task2FromL3(double ans) {
        boolean answer;
        answer = (ans == 120.00);
        return answer;
    }
    public static boolean task1FromL4(double ans) {
        boolean answer;
        answer = (ans == 2.50);
        return answer;
    }
    public static boolean task2FromL4(double ans) {
        boolean answer;
        answer = (ans == 35);
        return answer;
    }
    public static boolean task1FromL5(double ans) {
        boolean answer;
        answer = (ans == 30);
        return answer;
    }
    public static boolean task2FromL5(double ans) {
        boolean answer;
        answer = (ans == 3);
        return answer;
    }

}
