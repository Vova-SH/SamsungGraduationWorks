package com.example.visualphysics10.net;

import com.google.gson.annotations.SerializedName;

public class Testings {
    @SerializedName("id")
    public long id;
    @SerializedName("overview")
    public String description;
}
