package com.clean.arch.mvvm.data.dao

import androidx.room.Dao

@Dao
interface MovieDao