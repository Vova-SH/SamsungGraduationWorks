package com.clean.arch.mvvm.utils

const val API_KEY = "2e774b038b2dc15a1db7397f1b6b63a7"
const val BASE_URL = "https://api.themoviedb.org/3/"
const val IMAGE_URL = "https://themoviedb.org/t/p/w300"
const val IMAGE_ORIGINAL_URL = "https://themoviedb.org/t/p/original"
const val BACKDROP_URL = "https://themoviedb.org/t/p/w780"