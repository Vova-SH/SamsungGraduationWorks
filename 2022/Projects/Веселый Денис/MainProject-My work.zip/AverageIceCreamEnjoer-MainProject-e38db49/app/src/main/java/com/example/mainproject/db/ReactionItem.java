package com.example.mainproject.db;

public class ReactionItem {
    public final String subjects;
    public final int product;

    public ReactionItem(String subjects, int product) {
        this.subjects = subjects;
        this.product = product;
    }
}
