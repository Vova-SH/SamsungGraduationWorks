package com.example.mainproject.db;

public class ReactionItem {
    public final Integer product;
    public final String reaction;

    public ReactionItem(Integer product, String reaction) {
        this.product = product;
        this.reaction = reaction;
    }
}
