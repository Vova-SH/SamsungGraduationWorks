package com.example.chasingthescore;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.Random;


public class Attention_Fragment extends Fragment {


    private Integer image[] = {R.drawable.circle,R.drawable.romb,R.drawable.square,R.drawable.shestiug,R.drawable.treug};
    private ImageView imageView;
    private Handler handler;
    private int tm;
    private int square=0;
    private int treug=0;
    private int shstiug=0;
    private int circle=0;
    private int romb=0;
    private int count = 0;
    private String TAG = "TAG";
    private LinearLayout attentionFragmentLinear;
    private Long curentTime, stopTime;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_attention_, container, false);
        curentTime = System.currentTimeMillis() / 1000;
        imageView = view.findViewById(R.id.image);
        attentionFragmentLinear = view.findViewById(R.id.attentionFragmentLinear);
        attentionFragmentLinear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                view.setEnabled(false);
            }
        });
        handler = new Handler();
        String level = getArguments().getString("level");
        if(level!=null){
            switch(level){
                case "easy":
                    count = 0;
                    handler.post(showInfo);
                    break;
                case  "middle":
                    count = 1;
                    handler.post(showInfo);
                    break;
                case  "hard":
                    count = 2;
                    handler.post(showInfo);
                    break;
            }
        }

        return view;
    }
    Runnable showInfo = new Runnable() {
        @Override
        public void run() {
            stopTime = System.currentTimeMillis() / 1000;
            if ((stopTime - curentTime) < 10)//показывать первые 10 секунд
                PostHandler(handler);
            else {
                Fragment f2 = new Result_Attention();
                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                Bundle bundle = new Bundle();
                bundle.putInt("resultcir", circle);
                bundle.putInt("resultsqr", square);
                bundle.putInt("resultrom", romb);
                bundle.putInt("resultshs", shstiug);
                bundle.putInt("resulttre", treug);
                bundle.putInt("numberQuestion", randomNumber());

                f2.setArguments(bundle);
                ft.replace(R.id.container,f2);
                ft.commit();
            }
            Log.d(TAG, stopTime - curentTime + " " + curentTime + " " + stopTime);
        }
    };
    private void PostHandler(Handler handler) {
        switch (count) {
            case 0:
                tm = 2500;
                break;
            case 1:
                tm = 2000;
                break;
            case 2:
                tm = 1000;
                break;
        }
        int randomChar = (int)(Math.random()*image.length);
        Integer imageStr = image[randomChar];
        switch (randomChar){
            case 0:
                circle+=1;
                break;
            case 1:
                romb+=1;
                break;
            case 2:
                square+=1;
                break;
            case 3:
                shstiug+=1;
                break;
            case 4:
                treug+=1;
                break;
        }
        imageView.setImageResource(imageStr);
        randomColor();
        handler.postDelayed(showInfo, tm);
    }



    private void randomColor() {
        Random rnd = new Random();
        int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
        attentionFragmentLinear.setBackgroundColor(color);
    }

    private int randomNumber(){
        int Number = (int) (Math.random()*5);
        return Number;
    }

    public void onBackPressed() {
        //super.onBackPressed();
    }
}