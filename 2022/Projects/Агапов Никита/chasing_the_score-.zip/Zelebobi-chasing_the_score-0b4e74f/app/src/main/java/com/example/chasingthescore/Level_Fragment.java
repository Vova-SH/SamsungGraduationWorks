package com.example.chasingthescore;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class Level_Fragment extends Fragment {
    private Button btnBack1, btnEasy, btnMiddle, btnHard;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_level_, container, false);
        btnBack1 = view.findViewById(R.id.btnBack);
        btnEasy = view.findViewById(R.id.easy);
        btnMiddle = view.findViewById(R.id.middle);
        btnHard = view.findViewById(R.id.hard);
        String game = getArguments().getString("game");
        if (game != null) {


            btnEasy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    switch (game) {
                        case "math":
                            Fragment f4 = new Math_Fragment();
                            FragmentTransaction ft4 = getActivity().getSupportFragmentManager().beginTransaction();
                            Bundle bundle = new Bundle();
                            bundle.putString("level","easy");
                            f4.setArguments(bundle);
                            ft4.replace(R.id.container,f4);
                            ft4.commit();
                            break;
                        case "attention":
                            Fragment f7 = new Attention_Fragment();
                            FragmentTransaction ft7 = getActivity().getSupportFragmentManager().beginTransaction();
                            Bundle bundle1 = new Bundle();
                            bundle1.putString("level","middle");
                            f7.setArguments(bundle1);
                            ft7.replace(R.id.container,f7);
                            ft7.commit();
                            break;


                    }
                }
            });
            btnMiddle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    switch (game) {
                        case "math":
                            Fragment f6 = new Math_Fragment();
                            FragmentTransaction ft6 = getActivity().getSupportFragmentManager().beginTransaction();
                            Bundle bundle = new Bundle();
                            bundle.putString("level","middle");
                            f6.setArguments(bundle);
                            ft6.replace(R.id.container,f6);
                            ft6.commit();
                            break;
                        case "attention":
                            Fragment f7 = new Attention_Fragment();
                            FragmentTransaction ft7 = getActivity().getSupportFragmentManager().beginTransaction();
                            Bundle bundle1 = new Bundle();
                            bundle1.putString("level","middle");
                            f7.setArguments(bundle1);
                            ft7.replace(R.id.container,f7);
                            ft7.commit();
                            break;
                    }
                }
            });
            btnHard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    switch (game) {
                        case "math":
                            Fragment f8 = new Math_Fragment();
                            FragmentTransaction ft8 = getActivity().getSupportFragmentManager().beginTransaction();
                            Bundle bundle = new Bundle();
                            bundle.putString("level","hard");
                            f8.setArguments(bundle);
                            ft8.replace(R.id.container,f8);
                            ft8.commit();
                            break;
                        case "attention":
                            Fragment f9 = new Attention_Fragment();
                            FragmentTransaction ft9 = getActivity().getSupportFragmentManager().beginTransaction();
                            Bundle bundle1 = new Bundle();
                            bundle1.putString("level","hard");
                            f9.setArguments(bundle1);
                            ft9.replace(R.id.container,f9);
                            ft9.commit();
                            break;
                    }
                }
            });
        }
        btnBack1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment f2 = new Main_Game_Fragment();
                FragmentTransaction ft1 = getActivity().getSupportFragmentManager().beginTransaction();
                ft1.replace(R.id.container, f2);
                ft1.commit();
            }
        });
        return view;
    }
}